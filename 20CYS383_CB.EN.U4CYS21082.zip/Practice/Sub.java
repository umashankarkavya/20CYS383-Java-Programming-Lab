package practise.gui;

public class Sub {
    public static void main(String[] args) {
        int x=30;
        int y=15;
        int sub=x-y;
        System.out.println(sub);
    }
}
